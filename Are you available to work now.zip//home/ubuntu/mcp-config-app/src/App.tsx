import React, { useState, useEffect } from 'react';
import SearchFilters from './components/SearchFilters';
import ServerList from './components/ServerList';
import ConfigurationList from './components/ConfigurationList';
import ConfigurationWizard from './components/ConfigurationWizard';
import { MCPServer, MCPConfiguration, SearchFilters as SearchFiltersType } from './types';
import MCPServerService from './services/mcpServerService';
import ConfigurationService from './services/configurationService';

import './App.css';

const App: React.FC = () => {
  // Services
  const serverService = new MCPServerService();
  const configService = new ConfigurationService();

  // State
  const [servers, setServers] = useState<MCPServer[]>([]);
  const [filteredServers, setFilteredServers] = useState<MCPServer[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [configurations, setConfigurations] = useState<MCPConfiguration[]>([]);
  const [selectedConfigId, setSelectedConfigId] = useState<string | null>(null);
  const [showWizard, setShowWizard] = useState(false);
  const [editingConfig, setEditingConfig] = useState<MCPConfiguration | undefined>(undefined);
  const [activeTab, setActiveTab] = useState('search'); // 'search' or 'configurations'
  const [message, setMessage] = useState<{text: string, type: 'success' | 'error'} | null>(null);

  // Load initial data
  useEffect(() => {
    // Load servers
    const allServers = serverService.getAllServers();
    setServers(allServers);
    setFilteredServers(allServers);
    
    // Load categories
    const allCategories = serverService.getCategories();
    setCategories(allCategories);
    
    // Load configurations
    const allConfigurations = configService.getAllConfigurations();
    setConfigurations(allConfigurations);
  }, []);

  // Handle filter changes
  const handleFilterChange = (filters: SearchFiltersType) => {
    const results = serverService.searchServers(filters);
    setFilteredServers(results);
  };

  // Handle adding server to configuration
  const handleAddToConfig = (serverId: string, configId: string) => {
    try {
      const server = serverService.getServerById(serverId);
      if (!server) {
        showMessage('Server not found', 'error');
        return;
      }

      const serverConfig = {
        serverId,
        args: [...server.defaultArgs],
        tokenValue: server.requiresToken ? '' : undefined,
        enabled: true
      };

      const updatedConfig = configService.addServerToConfiguration(configId, serverConfig);
      
      // Update configurations list
      setConfigurations(configurations.map(c => 
        c.id === updatedConfig.id ? updatedConfig : c
      ));
      
      showMessage(`Added ${server.name} to configuration`, 'success');
    } catch (error) {
      showMessage(`Failed to add server to configuration: ${error.message}`, 'error');
    }
  };

  // Handle creating a new configuration
  const handleCreateConfig = (name: string, callback?: (configId: string) => void) => {
    try {
      const newConfig = configService.createConfiguration(name, '');
      setConfigurations([...configurations, newConfig]);
      
      if (callback) {
        callback(newConfig.id);
      }
      
      showMessage('Configuration created successfully', 'success');
      return newConfig.id;
    } catch (error) {
      showMessage(`Failed to create configuration: ${error.message}`, 'error');
      return null;
    }
  };

  // Handle saving a configuration
  const handleSaveConfiguration = (config: MCPConfiguration) => {
    try {
      const updatedConfig = configService.updateConfiguration(config);
      
      // Update configurations list
      setConfigurations(configurations.map(c => 
        c.id === updatedConfig.id ? updatedConfig : c
      ));
      
      setShowWizard(false);
      setEditingConfig(undefined);
      showMessage('Configuration saved successfully', 'success');
    } catch (error) {
      showMessage(`Failed to save configuration: ${error.message}`, 'error');
    }
  };

  // Handle deleting a configuration
  const handleDeleteConfiguration = (configId: string) => {
    try {
      const success = configService.deleteConfiguration(configId);
      
      if (success) {
        setConfigurations(configurations.filter(c => c.id !== configId));
        
        if (selectedConfigId === configId) {
          setSelectedConfigId(null);
        }
        
        showMessage('Configuration deleted successfully', 'success');
      } else {
        showMessage('Failed to delete configuration', 'error');
      }
    } catch (error) {
      showMessage(`Failed to delete configuration: ${error.message}`, 'error');
    }
  };

  // Handle selecting a configuration
  const handleSelectConfiguration = (configId: string) => {
    setSelectedConfigId(configId);
  };

  // Handle saving desktop config
  const handleSaveDesktopConfig = () => {
    if (!selectedConfigId) {
      showMessage('No configuration selected', 'error');
      return;
    }
    
    try {
      const savedPath = configService.saveDesktopConfig(selectedConfigId);
      showMessage(`Configuration saved to ${savedPath}`, 'success');
    } catch (error) {
      showMessage(`Failed to save desktop configuration: ${error.message}`, 'error');
    }
  };

  // Show message with auto-dismiss
  const showMessage = (text: string, type: 'success' | 'error') => {
    setMessage({ text, type });
    setTimeout(() => setMessage(null), 5000);
  };

  // Start wizard for creating/editing configuration
  const startWizard = (config?: MCPConfiguration) => {
    setEditingConfig(config);
    setShowWizard(true);
  };

  return (
    <div className="app">
      <header className="app-header">
        <h1>MCP Configuration Tool</h1>
        <div className="tabs">
          <button 
            className={activeTab === 'search' ? 'active' : ''}
            onClick={() => setActiveTab('search')}
          >
            Search MCP Servers
          </button>
          <button 
            className={activeTab === 'configurations' ? 'active' : ''}
            onClick={() => setActiveTab('configurations')}
          >
            My Configurations
          </button>
        </div>
      </header>

      {message && (
        <div className={`message ${message.type}`}>
          {message.text}
        </div>
      )}

      <main className="app-content">
        {showWizard ? (
          <ConfigurationWizard 
            servers={servers}
            onSaveConfiguration={handleSaveConfiguration}
            onCancel={() => {
              setShowWizard(false);
              setEditingConfig(undefined);
            }}
            initialConfig={editingConfig}
          />
        ) : (
          activeTab === 'search' ? (
            <div className="search-view">
              <SearchFilters 
                categories={categories}
                onFilterChange={handleFilterChange}
              />
              <ServerList 
                servers={filteredServers}
                configurations={configurations}
                onAddToConfig={handleAddToConfig}
                onCreateConfig={handleCreateConfig}
              />
            </div>
          ) : (
            <div className="configurations-view">
              <div className="configurations-container">
                <ConfigurationList 
                  configurations={configurations}
                  onSelectConfiguration={handleSelectConfiguration}
                  onDeleteConfiguration={handleDeleteConfiguration}
                  onCreateConfiguration={() => startWizard()}
                />
                
                <div className="configuration-actions">
                  {selectedConfigId && (
                    <>
                      <button 
                        className="edit-config-btn"
                        onClick={() => {
                          const config = configurations.find(c => c.id === selectedConfigId);
                          if (config) {
                            startWizard(config);
                          }
                        }}
                      >
                        Edit Configuration
                      </button>
                      <button 
                        className="save-desktop-btn"
                        onClick={handleSaveDesktopConfig}
                      >
                        Save to Claude Desktop
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>
          )
        )}
      </main>

      <footer className="app-footer">
        <p>MCP Configuration Tool for Claude Sonnet Desktop</p>
      </footer>
    </div>
  );
};

export default App;
