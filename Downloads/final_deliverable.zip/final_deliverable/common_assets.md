# Common Assets Analysis
## Icons
icon-creator.svg
icon-developer.svg
icon-enhance.svg
icon-file-system.svg
icon-hugging-face.svg
icon-researcher.svg
icon-simplicity.svg
icon-time.svg
icon-web-search.svg

## Illustrations
hero-illustration.svg
step1-illustration.svg
step2-illustration.svg
step3-illustration.svg

## Logos
homepage
pricing_page

## CSS Files
/home/ubuntu/combined_project/extracted/dashboard/dashboard.css
/home/ubuntu/combined_project/extracted/homepage/updated_mcp_homepage_package/styles.css
/home/ubuntu/combined_project/extracted/pricing_page/pricing_page_package/pricing-page.css
/home/ubuntu/combined_project/extracted/pricing_page/pricing_page_package/styles.css

## JavaScript Files
/home/ubuntu/combined_project/extracted/dashboard/dashboard.js
/home/ubuntu/combined_project/extracted/homepage/updated_mcp_homepage_package/script.js
/home/ubuntu/combined_project/extracted/pricing_page/pricing_page_package/pricing-page.js
/home/ubuntu/combined_project/extracted/pricing_page/pricing_page_package/script.js

## HTML Files
/home/ubuntu/combined_project/extracted/dashboard/dashboard.html
/home/ubuntu/combined_project/extracted/homepage/updated_mcp_homepage_package/updated_mcp_homepage.html
/home/ubuntu/combined_project/extracted/pricing_page/pricing_page_package/pricing.html
